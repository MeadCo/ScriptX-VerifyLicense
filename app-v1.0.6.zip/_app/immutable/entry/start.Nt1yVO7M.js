import{l as o,a as r}from"../chunks/DZ4_CULI.js";export{o as load_css,r as start};
